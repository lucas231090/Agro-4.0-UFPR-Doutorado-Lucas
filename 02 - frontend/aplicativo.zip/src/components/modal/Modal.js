import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  Image,
} from "react-native";

const { height } = Dimensions.get("window");

const Modal = ({ show, close }) => {
  const [state, setState] = useState({
    opacity: new Animated.Value(0),
    container: new Animated.Value(height),
    modal: new Animated.Value(height),
  });

  const openModal = () => {
    Animated.sequence([
      Animated.timing(state.container, { toValue: 0, duration: 100 }),
      Animated.timing(state.opacity, { toValue: 1, duration: 300 }),
      Animated.spring(state.modal, {
        toValue: 0,
        bounciness: 5,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const closeModal = () => {
    Animated.sequence([
      Animated.timing(state.modal, {
        toValue: height,
        duration: 250,
        useNativeDriver: true,
      }),
      Animated.timing(state.opacity, { toValue: 0, duration: 300 }),
      Animated.timing(state.container, { toValue: height, duration: 100 }),
    ]).start();
  };

  useEffect(() => {
    if (show) {
      openModal();
    } else {
      closeModal();
    }
  }, [show]);

  return (
      
    <Animated.View
      style={[
        styles.container,
        {
          opacity: state.opacity,
          transform: [{ translateY: state.container }],
        },
      ]}
    >
      <Animated.View
        style={[
          styles.modal,
          {
            transform: [{ translateY: state.modal }],
          },
        ]}
      >
        <View style={styles.indicator} />

        <Image
          style={styles.image}
          source={{
            uri:
              "https://cdn2.iconfinder.com/data/icons/future-farming-flat/96/future-farming-technology-agriculture-science-512.png",
          }}
        />
        <Text style={styles.name}>DHT11</Text>
        <Text style={styles.position}>Fabricante:</Text>
        <Text style={styles.position}>Calibrado em:</Text>
        <Text style={styles.about}>
          O Sensor permite fazer leituras de temperaturas entre 0 a 50 Celsius e
          umidade entre 20 a 90%, muito usado para projetos com Arduino. 
        </Text>

        <TouchableOpacity style={styles.btn} onPress={close}>
          <Text style={{ color: "#fff", fontSize: 18, alignSelf: "center" }}>
            Fechar
          </Text>
        </TouchableOpacity>
      </Animated.View>
    </Animated.View>
  );
};
//position: 'absolute' container
const styles = StyleSheet.create({
  container: {
    backgroundColor: "#00000057",
    flex: 1,
    position: "absolute",
  },

  modal: {
    backgroundColor: "#FFF",
    marginTop: "10%",
    flex: 1,
    borderRadius: 10,
    marginBottom: 500,
  },
  indicator: {
    width: 75,
    height: 5,
    backgroundColor: "#ccc",
    borderRadius: 50,
    alignSelf: "center",
    marginTop: 25,
  },

  image: {
    width: 90,
    height: 90,
    borderRadius: 30,
  },
  name: {
    fontSize: 22,
    flex: 1,
    alignSelf: "center",
    color: "#008080",
    fontWeight: "bold",
  },
  position: {
    fontSize: 12,
    flex: 1,
    alignSelf: "center",
    color: "#696969",
    fontWeight: "bold",
  },
  about: {
    marginHorizontal: 10,
    textAlign: "justify",
    fontSize: 16,
    padding: 10,
  },

  btn: {
    width: 150,
    height: 50,
    borderRadius: 50,
    backgroundColor: "#2ecc71",
    justifyContent: "center",
    alignItems: "center",
    alignSelf: "center",
    marginHorizontal: 100,
    flex: 1,
    marginBottom: 10,
    marginTop: 15,
  },
});

export default Modal;
