import { Animated } from 'react-native';
import styled from 'styled-components/native';

export const Container = styled(Animated.View)`
  height: 150px;
  margin-top: 20px;
`;

export const TabsContainer = styled.ScrollView.attrs({
  horizontal: true,
  contentContainerStyle: { paddingLeft: 10, paddingRight: 20 },
  showsHorizontalScrollIndicator: false,
})``;

export const TabItem = styled.View`
  width: 100px;
  height: 100px;
  background: rgba(255, 255, 255, 0.8);
  border-radius: 3px;
  margin-left: 10px;
  padding: 10px;
  justify-content: space-between;
`;

export const TabText = styled.Text`
  font-size: 13px;
  color: #000;
`;

export const Content = styled.View`
  max-height: 400px;
  
`;

export const Card = styled(Animated.View)`
  background: #8B10AE;
  border-radius: 4px;
  height: 75%;
  width: 75%;
`;

export const CardHeader = styled.View`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding: 12px;
`;

export const CardContent = styled.View`
  padding: 0 5px;
`;

export const Title = styled.Text`
  font-size: 18px;
  color: #000;
  alignSelf: baseline;
`;

export const Description = styled.Text`
  font-size: 25px;
  color: #666;
  alignSelf: center  
`;

export const CardFooter = styled.View`
  
  padding: 30px;
  background: #eee;
  border-radius: 4px;
`;

export const Annotation = styled.Text`
  font-size: 30px;
  fontWeight: bold;
  color: #000;
`;


export const SafeAreaView = styled.SafeAreaView`
  flex: 1;
  background: #8B10AE;
`;





