import React from 'react'
import { StackedBarChart } from 'react-native-svg-charts'

class StackedBarChartExample extends React.PureComponent {
    render() {
        const data = [
            {
                vermelho: 4,
                laranja: 3,
                amarelo:1,
                verde: 15,
                amarelo1:1,
                laranja1:3,
                vermelho1:4
            }
           
        ]
        const colors = [ '#CC0000', '#E67E22', '#FFEE58' ,'#2ECC71', '#FFEE58', '#E67E22', '#CC0000']
        const keys = ['vermelho', 'laranja', 'amarelo', 'verde', 'amarelo1', 'laranja1', 'vermelho1']

        return (
            <StackedBarChart
                style={{ height: 15, width:200 }}
                keys={keys}
                colors={colors}
                data={data}
                horizontal={true}
            />
        )
    }
  }

  export default StackedBarChartExample