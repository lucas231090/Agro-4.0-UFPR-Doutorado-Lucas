import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Dimensions
} from "react-native";

import {
  Card,
  CardItem,
  Left,
  Right,
  Body,
  Spinner,
  Thumbnail,
} from "native-base";

//import { Chart, Line, Area, HorizontalAxis, VerticalAxis, Tooltip } from 'react-native-responsive-linechart'

import api from '/Projetos/agro/app/src/services/api'

import LineGraph from '@chartiful/react-native-line-graph'

//coleção de icones
import typeIcons from '../../../utils/typeIcons'

import Modal from "../../../components/modal/Modal";
//import { array } from "yup";

//Temperatura

let Temperaturas = [
  { "x": 0, "y": 15 },
  { "x": -1, "y": 10 },
  { "x": 0, "y": 12 },
  { "x": 1, "y": 7 },
  { "x": 2, "y": 6 },
  { "x": 3, "y": 3 },
  { "x": 4, "y": 5 },
  { "x": 10, "y": 18 }
];

function CardIndicadores({title, when, type}) {

  const [mediaTemperatura, setMediaTemperatura] = useState();

  const [ultimoDado, setUltimoDado] = useState();

  const [dadosGrafico, setDadosGrafico] = useState()

  //const [labelsGrafico, setLabelsGrafico] = useState()

  useEffect(() => {
    
    api.get('/sensores/temperaturas').then(response => {
      const temperatura = response.data;
   
      const MediaTemperatura =
        temperatura.reduce(
          (total, currentValue) => (total += currentValue),0
        ) / temperatura.length

      setMediaTemperatura(MediaTemperatura.toFixed(2));
    });

    api.get('/sensores/ultimatemperatura').then(response => {
      
      const ultimatemperatura = response.data;

      const arrayUltimaTemp = ultimatemperatura.reduce((total) => (total)).toFixed(2)

      setUltimoDado(arrayUltimaTemp);
  });

 api.get('/sensores/temperaturas').then(response => {
 // api.get('/sensores/objeto').then(response => {
      
   const objetosGrafico = response.data;

   const arrayObjetos = objetosGrafico.map(value => value)

   setDadosGrafico(arrayObjetos);
});

//api.get('/sensores/temperaturatimestamp').then(response => {
         
//    const labelsgrafico = response.data;

  // const arrayObjetos = labelsgrafico.map(value => value)

 
    //setLabelsGrafico(arrayObjetos);
// });
 
}, []);

  

  
 const [modal, setModal] = useState(false);
  
  return (
    <>
      <View>
        <ScrollView>
          <Card>
            
           
           {/*Cabeçalho*/}

           <CardItem style={{height:60 }}>
              <Left>
                <Thumbnail
                  style={{height:45, width:40}}
                  source={{uri: "https://st2.depositphotos.com/5266903/8982/v/950/depositphotos_89823200-stock-illustration-temperature-level-rounded-vector-icon.jpg"}}
                />
                <Body>
                  <Text style={styles.medida}>Temperatura</Text>
                  <Text style={styles.unidade}>ºC</Text>
                </Body>
                <Right>
                <TouchableOpacity onPress={() => {}}>
                <Image
                  style={{height:35, width:35}}
                  source={{
                    uri:
                      "https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/80-256.png",
                  }}
                />
              </TouchableOpacity>                  
                </Right>
              </Left>
            </CardItem>

            {/*Grafico*/}
           <View style={{flex:1}}>

           <LineGraph
          data={dadosGrafico}
         //labels={labelsGrafico}
          width={Dimensions.get('window').width - 25}
          height={300}
          lineColor='#347875'
          //dotColor='#347975'
          lineWidth={2}
          hasDots={false}
          //otSize={3}
          hasShadow={false}
          baseConfig={{
          startAtZero: false,
          hasXAxisBackgroundLines: true,
          xAxisLabelStyle: {
         // suffix: 'ºC',
        //xOffset: -15,
          decimals: true,
          color: '#000',
          fontSize:12,
               
          },
          yAxisLabelStyle:{
            fontSize:8,
            height:20,
            xOffset:-5,
            yOffset:3,
            rotation:-90,
          },
          xAxisLabelCount: 10,
         // yAxisLabelCount:10        

  }}
          style={{
    paddingTop: 5,
    borderRadius: 20,
    width: Dimensions.get('window').width - 3,
    backgroundColor: `#dbf0ef`,
    marginLeft:1,
  }}
/>

              

          </View>

             {/*Rodapé*/}
            <CardItem footer>
              <Text style={styles.legenda}>Agora: {ultimoDado} ºC</Text>
              <Body />
              
              
              <Text style={styles.legenda}>Média: {mediaTemperatura} ºC</Text>
            </CardItem>

           {/*Mais infos e detalhes */}

           <View style={styles.container}>
          
              <TouchableOpacity onPress={() => setModal(true)}>
                <Image
                  style={styles.icon}
                  source={{
                    uri: "https://img.icons8.com/clouds/2x/information.png",
                  }}
                />
                <Text style={styles.detalhe}>Informações</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => {}}>
                <Image
                  style={styles.icon}
                  source={{
                    uri:
                      "https://cdn4.iconfinder.com/data/icons/big-data-analytics-volume-1/64/business-intelligent-512.png",
                  }}
                />
                <Text style={styles.detalhe}>Gerenciar</Text>
              </TouchableOpacity>
            </View>
            
     
          </Card>
        </ScrollView>
      </View>

    <Modal show={modal} close={() => setModal(false)} /> 

    </>
  );
}

export default CardIndicadores;

const styles = StyleSheet.create({
 
  areaGrafico: {
    flexDirection: "row",
    shadowOffset: { width: 5 },
    shadowOpacity: 0.4,
    backgroundColor:'#ffb6c1',
    height:'107%',
    flex:1
  },
  legenda: {
    fontSize: 16,
    color: "#2ecc71",
    fontWeight: "bold",
  },
  detalhe: {
    backgroundColor: "#2ecc71",
    width: `100%`,
    color: "#FFF",
    fontSize: 15,
    marginEnd: 100,
    marginBottom: 10,
    textAlign: "center"
  },
  
  icon: {
    width: 35,
    height: 35,
    backgroundColor: "#fff",
    alignSelf: "center",
  },
  container: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
})

