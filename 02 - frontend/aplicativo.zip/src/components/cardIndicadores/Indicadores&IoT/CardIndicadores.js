import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Dimensions
} from "react-native";

import {
  Card,
  CardItem,
  Left,
  Right,
  Body,
  Spinner,
  Thumbnail,
} from "native-base";

import api from '/Projetos/agro/app/src/services/api'

//import { Chart, Line, Area, HorizontalAxis, VerticalAxis, Tooltip } from 'react-native-responsive-linechart'


import LineGraph from '@chartiful/react-native-line-graph'

//coleção de icones
//import typeIcons from '../../../utils/typeIcons'

import Modal from "../../../components/modal/Modal";
//import { array } from "yup";

//Temperatura

let Temperaturas = [
  { "x": 0, "y": 15 },
  { "x": -1, "y": 10 },
  { "x": 0, "y": 12 },
  { "x": 1, "y": 7 },
  { "x": 2, "y": 6 },
  { "x": 3, "y": 3 },
  { "x": 4, "y": 5 },
  { "x": 10, "y": 18 }
];

function CardIndicadores({title, when, type}) {

  const [filter, setFilter] = useState('all')
  
  const [mediaDados, setMediaDados] = useState("--");
  const [ultimoDado, setUltimoDado] = useState("--");
  const [dadosGraficoTemperatura, setDadosGraficoTemperatura] = useState()


  const [mediaUmidade, setMediaUmidade] = useState("--");
  const [ultimoDadoUmidade, setUltimoDadoUmidade] = useState("--");
  const [dadosGraficoUmidade, setDadosGraficoUmidade] = useState()

  const [mediaCO2, setMediaCO2] = useState("--");
  const [ultimoDadoCO2, setUltimoDadoCO2] = useState("--");
  const [dadosGraficoCO2, setDadosGraficoCO2] = useState()


  //const [labelsGrafico, setLabelsGrafico] = useState()

  useEffect(() => {
    
    api.get(`/sensores/${filter}/temperatura`).then(response => {
      
      const temperatura = response.data;
   
      const MediaDados =
        temperatura.reduce(
          (total, currentValue) => (total += currentValue),0
        ) / temperatura.length

      const arrayObjetos = temperatura.map(value => value)

      const arrayUltimaTemp = temperatura.reduce((total) => (total)).toFixed(2)

      setUltimoDado(arrayUltimaTemp);

      setDadosGraficoTemperatura(arrayObjetos);

      setMediaDados(MediaDados.toFixed(2));

      
    });


api.get(`/sensores/${filter}/umidade`).then(response => {
  const umidade = response.data;

  const MediaUmidade =
    umidade.reduce(
      (total, currentValue) => (total += currentValue),0
    ) / umidade.length

    const arrayObjetos = umidade.map(value => value)

    const arrayUltimaUmid = umidade.reduce((total) => (total)).toFixed(2)

  setUltimoDadoUmidade(arrayUltimaUmid);

  setDadosGraficoUmidade(arrayObjetos);

  setMediaUmidade(MediaUmidade.toFixed(2));
});

api.get(`/sensores/${filter}/gasesCO2`).then(response => {
  const co2 = response.data;

  const Mediaco2 =
    co2.reduce(
      (total, currentValue) => (total += currentValue),0
    ) / co2.length

    const arrayObjetos = co2.map(value => value)

    const arrayUltimaco2 = co2.reduce((total) => (total)).toFixed(2)

    setUltimoDadoCO2(arrayUltimaco2);

  setDadosGraficoCO2(arrayObjetos);

  setMediaCO2(Mediaco2.toFixed(2));
});
 
}, [filter]);
  
 const [modal, setModal] = useState(false);
  
  return (
    <>

<View style={styles.filter}>
     <TouchableOpacity onPress={() => setFilter('all')}>
      <Text style={
        filter == 'all' ? styles.filterActived : styles.filterInatived
        }>Todos</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => setFilter('today')}>
      <Text style={filter == 'today' ? styles.filterActived : styles.filterInatived}>Hoje</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => setFilter('week')}>
      <Text style={filter == 'week' ? styles.filterActived : styles.filterInatived}>Semana</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => setFilter('month')}>
      <Text style={filter == 'month' ? styles.filterActived : styles.filterInatived}>Mês</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => setFilter('year')}>
      <Text style={filter == 'year' ? styles.filterActived : styles.filterInatived}>Ano</Text>
      </TouchableOpacity>  
</View>

      <View>
        <ScrollView>


          <Card>
                      
           {/*Cabeçalho*/}

           <CardItem style={{height:60 }}>
              <Left>
                <Thumbnail
                  style={{height:45, width:40}}
                  source={{uri: "https://st2.depositphotos.com/5266903/8982/v/950/depositphotos_89823200-stock-illustration-temperature-level-rounded-vector-icon.jpg"}}
                />
                <Body>
                  <Text style={styles.medida}>Temperatura</Text>
                  <Text style={styles.unidade}>ºC</Text>
                </Body>
                <Right>
                <TouchableOpacity onPress={() => {}}>
                <Image
                  style={{height:35, width:35}}
                  source={{
                    uri:
                      "https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/80-256.png",
                  }}
                />
              </TouchableOpacity>                  
                </Right>
              </Left>
            </CardItem>

            {/*Grafico*/}
           <View style={{flex:1}}>

           <LineGraph
          data={dadosGraficoTemperatura}
         //labels={labelsGrafico}
          width={Dimensions.get('window').width - 25}
          height={300}
          lineColor='#347875'
          //dotColor='#347975'
          lineWidth={2}
          hasDots={false}
          //otSize={3}
          hasShadow={false}
          baseConfig={{
          startAtZero: false,
          hasXAxisBackgroundLines: true,
          xAxisLabelStyle: {
         // suffix: 'ºC',
        //xOffset: -15,
          decimals: true,
          color: '#000',
          fontSize:12,
               
          },
          yAxisLabelStyle:{
            fontSize:8,
            height:20,
            xOffset:-5,
            yOffset:3,
            rotation:-90,
          },
          xAxisLabelCount: 10,
         // yAxisLabelCount:10        

  }}
          style={{
    paddingTop: 5,
    borderRadius: 20,
    width: Dimensions.get('window').width - 3,
    backgroundColor: `#dbf0ef`,
    marginLeft:1,
  }}
/>            

          </View>

             {/*Rodapé*/}
            <CardItem footer>
              <Text style={styles.legenda}>Agora: {ultimoDado} ºC</Text>
              <Body />
              
              
              <Text style={styles.legenda}>Média: {mediaDados} ºC</Text>
            </CardItem>

           {/*Mais infos e detalhes */}

           <View style={styles.container}>
          
              <TouchableOpacity onPress={() => setModal(true)}>
                <Image
                  style={styles.icon}
                  source={{
                    uri: "https://img.icons8.com/clouds/2x/information.png",
                  }}
                />
                <Text style={styles.detalhe}>Informações</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => {}}>
                <Image
                  style={styles.icon}
                  source={{
                    uri:
                      "https://cdn4.iconfinder.com/data/icons/big-data-analytics-volume-1/64/business-intelligent-512.png",
                  }}
                />
                <Text style={styles.detalhe}>Gerenciar</Text>
              </TouchableOpacity>
            </View>          
          </Card>

          <Card>
            {/* SEGUNDO card */}
            {/* Cabeçalho */}
            <CardItem style={{height:60 }}>
              <Left>
                <Thumbnail
                  style={{height:45, width:40}}
                  source={{
                    uri:
                      "https://image.flaticon.com/icons/png/512/1582/1582784.png",
                 }}
                />
                <Body>
                  <Text style={styles.medida}>Umidade</Text>
                  <Text style={styles.unidade}>%</Text>
                </Body>
              </Left>
            </CardItem>

            {/* grafico */}
            <View style={{flex:1}}>
                
            <LineGraph
          data={dadosGraficoUmidade}
         //labels={labelsGrafico}
          width={Dimensions.get('window').width - 25}
          height={300}
          lineColor='#347875'
          //dotColor='#347975'
          lineWidth={2}
          hasDots={false}
          //otSize={3}
          hasShadow={false}
          baseConfig={{
          startAtZero: false,
          hasXAxisBackgroundLines: true,
          xAxisLabelStyle: {
         // suffix: 'ºC',
        //xOffset: -15,
          decimals: true,
          color: '#000',
          fontSize:12,
               
          },
          yAxisLabelStyle:{
            fontSize:8,
            height:20,
            xOffset:-5,
            yOffset:3,
            rotation:-90,
          },
          xAxisLabelCount: 10,
         // yAxisLabelCount:10        

  }}
          style={{
    paddingTop: 5,
    borderRadius: 20,
    width: Dimensions.get('window').width - 3,
    backgroundColor: `#dbf0ef`,
    marginLeft:1,
  }}
/>

            </View>
            {/* Rodapé */}
            <CardItem footer>
              <Text style={styles.legenda}>Agora: {ultimoDadoUmidade} %</Text>
              <Body />
              <Text style={styles.legenda}>Média: {mediaUmidade} %</Text>
            </CardItem>

            {/* MAIS INFORMAÇÕES E DETALHES */}
            
            <View style={styles.container}>
              <TouchableOpacity onPress={() => setModal(true)}>
                <Image
                  style={styles.icon}
                  source={{
                    uri: "https://img.icons8.com/clouds/2x/information.png",
                  }}
                />
                <Text style={styles.detalhe}>Informações</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => {}}>
                <Image
                  style={styles.icon}
                  source={{
                    uri:
                      "https://cdn4.iconfinder.com/data/icons/big-data-analytics-volume-1/64/business-intelligent-512.png",
                  }}
                />
                <Text style={styles.detalhe}>Gerenciar</Text>
              </TouchableOpacity>
            </View>
          </Card>

          <Card>
            {/* TERCEIRO card */}
            {/* Cabeçalho */}
            <CardItem style={{height:60 }}>
              <Left>
                <Thumbnail
                  source={{
                    uri:
                      "https://cdn0.iconfinder.com/data/icons/energy-68/33/energy-03-256.png",
                 }}
                />
                <Body>
                  <Text style={styles.medida}>Nível de CO2</Text>
                  <Text style={styles.unidade}>ppm (partes por milhão)</Text>
                </Body>
              </Left>
            </CardItem>

            {/* grafico */}
            <View style={{flex:1}}>
                
                <LineGraph
              data={dadosGraficoCO2}
             //labels={labelsGrafico}
              width={Dimensions.get('window').width - 25}
              height={300}
              lineColor='#347875'
              //dotColor='#347975'
              lineWidth={2}
              hasDots={false}
              //otSize={3}
              hasShadow={false}
              baseConfig={{
              startAtZero: false,
              hasXAxisBackgroundLines: true,
              xAxisLabelStyle: {
             // suffix: 'ºC',
            //xOffset: -15,
              decimals: true,
              color: '#000',
              fontSize:12,
                   
              },
              yAxisLabelStyle:{
                fontSize:8,
                height:20,
                xOffset:-5,
                yOffset:3,
                rotation:-90,
              },
              xAxisLabelCount: 10,
             // yAxisLabelCount:10        
    
      }}
              style={{
        paddingTop: 5,
        borderRadius: 20,
        width: Dimensions.get('window').width - 3,
        backgroundColor: `#dbf0ef`,
        marginLeft:1,
      }}
    />
    
                </View>
            {/* Rodapé */}
            <CardItem footer>
              <Text style={styles.legenda}>Agora: {ultimoDadoCO2} ppm</Text>
              <Body />
              <Text style={styles.legenda}>Média: {mediaCO2} ppm</Text>
            </CardItem>

            {/* MAIS INFORMAÇÕES E DETALHES */}
            
            <View style={styles.container}>
              <TouchableOpacity onPress={() => setModal(true)}>
                <Image
                  style={styles.icon}
                  source={{
                    uri: "https://img.icons8.com/clouds/2x/information.png",
                  }}
                />
                <Text style={styles.detalhe}>Informações</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => {}}>
                <Image
                  style={styles.icon}
                  source={{
                    uri:
                      "https://cdn4.iconfinder.com/data/icons/big-data-analytics-volume-1/64/business-intelligent-512.png",
                  }}
                />
                <Text style={styles.detalhe}>Gerenciar</Text>
              </TouchableOpacity>
            </View>
          </Card>

          <View style={{marginBottom:35}}>
            <Text style={{ fontSize: 12, textAlign: "center", color: "#cc0000" }}>
              Versão beta 0.1
            </Text> 
          </View>

        </ScrollView>
      </View>

    <Modal show={modal} close={() => setModal(false)} /> 

    </>
  );
}

export default CardIndicadores;

const styles = StyleSheet.create({
 
  areaGrafico: {
    flexDirection: "row",
    shadowOffset: { width: 5 },
    shadowOpacity: 0.4,
    backgroundColor:'#ffb6c1',
    height:'107%',
    flex:1
  },
  legenda: {
    fontSize: 16,
    color: "#2ecc71",
    fontWeight: "bold",
  },
  detalhe: {
    backgroundColor: "#2ecc71",
    width: `100%`,
    color: "#FFF",
    fontSize: 15,
    marginEnd: 100,
    marginBottom: 10,
    textAlign: "center"
  },
  
  icon: {
    width: 35,
    height: 35,
    backgroundColor: "#fff",
    alignSelf: "center",
  },
  container: {
    flexDirection: "row",
    justifyContent: "space-around",
  },

  filter:{
    backgroundColor: '#FFF',
    flexDirection: 'row',
    width: '100%',
    justifyContent:'space-around',
    height: 60,
    alignItems: 'center',
    borderTopWidth:3,
    borderBottomWidth:3,
    borderColor:'#2ecc71'
  },
  filterActived:{
      fontWeight: 'bold',
      fontSize:18,
      color:'#2ecc71'
  },
  filterInatived:{
    fontWeight: 'bold',
    fontSize:18,
    color:'#808080',
},

})

