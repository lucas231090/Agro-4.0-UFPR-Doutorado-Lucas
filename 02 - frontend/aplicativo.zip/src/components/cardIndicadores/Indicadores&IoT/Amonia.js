import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  FlatList,
  StyleSheet,
} from "react-native";
import {
  Card,
  CardItem,
  Left,
  Right,
  Body,
  Thumbnail,
  Spinner,
} from "native-base";

import {
  LineChart,
  Grid,
  YAxis,
} from "react-native-svg-charts";


import Modal from "../../modal/Modal";


//Amonia

let Amonia = [1, 2, 3, 5, 18, 14, 12, 10, 8, 8, 8, 6, 10];

//Média de Amonia
let totalAmonia = 0;
for (let b in Amonia) {
  totalAmonia += Amonia[b];
}
let numsCntA = Amonia.length;
let MediaAmonia = (totalAmonia / numsCntA).toFixed(1);



function CardIndicadores() {
  const [modal, setModal] = useState(false);
  return (
    <>
      <View>
        <ScrollView>
          <Card>
            {/* PRIMEIRO card */}
            {/* Cabeçalho */}
            <CardItem style={{height:60 }}>
              <Left>
                <Thumbnail
                  source={{
                    uri:
                      "https://img.icons8.com/plasticine/2x/test-tube.png",
                 }}
                />
                <Body>
                  <Text style={styles.medida}>Nível de Amônia na granja</Text>
                  <Text style={styles.unidade}>%</Text>
                </Body>
              </Left>
            </CardItem>

            {/* grafico */}
            <CardItem
            style={{height:322, width:'100%'}}
            >
              <YAxis
                data={Amonia}
                svg={{
                  fill: "black",
                  fontSize: 9,
                }}
                numberOfTicks={10}
                formatLabel={(value) => `${value}%`}
              />
              <LineChart
                style={{flex:1}}
                data={Amonia}
                svg={{ stroke: "rgb(134, 65, 244)" }}
                contentInset={{ bottom: 0 }}
              >
                <Grid />
              </LineChart>
            </CardItem>

            {/* Rodapé */}
            <CardItem footer>
              <Text style={styles.legenda}>Agora: NaN ºC</Text>
              <Body />
              <Text style={styles.legenda}>Média: {MediaAmonia} ºC</Text>
            </CardItem>

            {/* MAIS INFORMAÇÕES E DETALHES */}
            
            <View style={styles.container}>
              <TouchableOpacity onPress={() => setModal(true)}>
                <Image
                  style={styles.icon}
                  source={{
                    uri: "https://img.icons8.com/clouds/2x/information.png",
                  }}
                />
                <Text style={styles.detalhe}>Informações</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => {}}>
                <Image
                  style={styles.icon}
                  source={{
                    uri:
                      "https://cdn4.iconfinder.com/data/icons/big-data-analytics-volume-1/64/business-intelligent-512.png",
                  }}
                />
                <Text style={styles.detalhe}>Gerenciar</Text>
              </TouchableOpacity>
            </View>
          </Card>
        </ScrollView>
      </View>
      <Modal show={modal} close={() => setModal(false)} />
    </>
  );
}

export default CardIndicadores;

const styles = StyleSheet.create({
 
  areaGrafico: {
    flexDirection: "row",
    shadowOffset: { width: 5 },
    shadowOpacity: 0.4,
    backgroundColor:'#ffb6c1',
    height:'107%',
    flex:1
  },
  legenda: {
    fontSize: 16,
    color: "#2ecc71",
    fontWeight: "bold",
  },
  detalhe: {
    backgroundColor: "#2ecc71",
    width: `100%`,
    color: "#FFF",
    fontSize: 15,
    marginEnd: 100,
    marginBottom: 10,
    textAlign: "center"
  },
  icon: {
    width: 35,
    height: 35,
    backgroundColor: "#fff",
    alignSelf: "center",
  },
  container: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
})