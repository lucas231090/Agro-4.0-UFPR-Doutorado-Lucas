import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Dimensions
} from "react-native";
import {
  Card,
  CardItem,
  Left,
  Body,
  Thumbnail,
} from "native-base";

//import {LineChart, Grid, YAxis} from "react-native-svg-charts";

//import VerticalBarGraph from '@chartiful/react-native-vertical-bar-graph';

import LineGraph from '@chartiful/react-native-line-graph'

import api from '/Projetos/agro/app/src/services/api'

import Modal from "../../modal/Modal";

//Umidade
let Umidade = [
  52,
  52,
  47,
  45,
  43,
  40,
  40

];

//Média de Umidade
let totalUmidade = 0;
for (let a in Umidade) {
  totalUmidade += Umidade[a];
}
let numsCntU = Umidade.length;
let MediaUmidade = (totalUmidade / numsCntU).toFixed(1);



function CardIndicadores() {

  const [modal, setModal] = useState(false);

  const [mediaUmidade, setMediaUmidade] = useState();

  const [ultimoDado, setUltimoDado] = useState();

  const [dadosGrafico, setDadosGrafico] = useState()
  

  useEffect(() => {
    
    api.get('/sensores/umidades').then(response => {
      const umidade = response.data;
   
      const MediaUmidade =
        umidade.reduce(
          (total, currentValue) => (total += currentValue),0
        ) / umidade.length

      setMediaUmidade(MediaUmidade.toFixed(2));
    });

    api.get('/sensores/ultimaumidade').then(response => {
      
      const ultimaumidade = response.data;

      const arrayUltimaUmid = ultimaumidade.reduce((total) => (total)).toFixed(2)

      setUltimoDado(arrayUltimaUmid);
  });

 api.get('/sensores/umidades').then(response => {
 // api.get('/sensores/objeto').then(response => {
      
   const objetosGrafico = response.data;

   const arrayObjetos = objetosGrafico.map(value => value)

   setDadosGrafico(arrayObjetos);
});


}, []);

  return (
    <>
      <View>
        <ScrollView>
          <Card>
            {/* PRIMEIRO card */}
            {/* Cabeçalho */}
            <CardItem style={{height:60 }}>
              <Left>
                <Thumbnail
                  style={{height:45, width:40}}
                  source={{
                    uri:
                      "https://image.flaticon.com/icons/png/512/1582/1582784.png",
                 }}
                />
                <Body>
                  <Text style={styles.medida}>Umidade</Text>
                  <Text style={styles.unidade}>%</Text>
                </Body>
              </Left>
            </CardItem>

            {/* grafico */}
            <View style={{flex:1}}>
                
            <LineGraph
          data={dadosGrafico}
         //labels={labelsGrafico}
          width={Dimensions.get('window').width - 25}
          height={300}
          lineColor='#347875'
          //dotColor='#347975'
          lineWidth={2}
          hasDots={false}
          //otSize={3}
          hasShadow={false}
          baseConfig={{
          startAtZero: false,
          hasXAxisBackgroundLines: true,
          xAxisLabelStyle: {
         // suffix: 'ºC',
        //xOffset: -15,
          decimals: true,
          color: '#000',
          fontSize:12,
               
          },
          yAxisLabelStyle:{
            fontSize:8,
            height:20,
            xOffset:-5,
            yOffset:3,
            rotation:-90,
          },
          xAxisLabelCount: 10,
         // yAxisLabelCount:10        

  }}
          style={{
    paddingTop: 5,
    borderRadius: 20,
    width: Dimensions.get('window').width - 3,
    backgroundColor: `#dbf0ef`,
    marginLeft:1,
  }}
/>

            </View>
            {/* Rodapé */}
            <CardItem footer>
              <Text style={styles.legenda}>Agora: {ultimoDado} %</Text>
              <Body />
              <Text style={styles.legenda}>Média: {mediaUmidade} %</Text>
            </CardItem>

            {/* MAIS INFORMAÇÕES E DETALHES */}
            
            <View style={styles.container}>
              <TouchableOpacity onPress={() => setModal(true)}>
                <Image
                  style={styles.icon}
                  source={{
                    uri: "https://img.icons8.com/clouds/2x/information.png",
                  }}
                />
                <Text style={styles.detalhe}>Informações</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => {}}>
                <Image
                  style={styles.icon}
                  source={{
                    uri:
                      "https://cdn4.iconfinder.com/data/icons/big-data-analytics-volume-1/64/business-intelligent-512.png",
                  }}
                />
                <Text style={styles.detalhe}>Gerenciar</Text>
              </TouchableOpacity>
            </View>
          </Card>
        </ScrollView>
      </View>
      <Modal show={modal} close={() => setModal(false)} />
    </>
  );
}

export default CardIndicadores;

const styles = StyleSheet.create({
 
  areaGrafico: {
    flexDirection: "row",
    shadowOffset: { width: 5 },
    shadowOpacity: 0.4,
    backgroundColor:'#ffb6c1',
    height:'107%',
    flex:1
  },
  legenda: {
    fontSize: 16,
    color: "#2ecc71",
    fontWeight: "bold",
  },
  detalhe: {
    backgroundColor: "#2ecc71",
    width: `100%`,
    color: "#FFF",
    fontSize: 15,
    marginEnd: 100,
    marginBottom: 10,
    textAlign: "center"
  },
  icon: {
    width: 35,
    height: 35,
    backgroundColor: "#fff",
    alignSelf: "center",
  },
  container: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
})