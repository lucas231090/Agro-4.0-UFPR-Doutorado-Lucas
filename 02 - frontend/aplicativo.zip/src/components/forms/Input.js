import React, {useEffect, useState, useRef, useCallback, useImperativeHandle, forwardRef} from 'react'
import {TextInputProps, TextInput, StyleSheet, View} from 'react-native'
import {useField} from '@unform/core'



const Input =({
    name, icon, ...rest
}, ref) =>{

    const inputElementRef = useRef(null)
    const {registerField, defaultValue = '', fieldName, error } = useField(name)
    const inputValueRef = useRef({value: ''})


    const [isFocused, setIsFocused] = useState(false)
    const [isFilled, setIsFilled] = useState(false)

    const handleInputFocus = useCallback(() =>{
        setIsFocused(true)
    }, [])


    const handleInputBlur = useCallback(() =>{
        setIsFocused(false)

        setIsFilled(!!inputValueRef.current.value)
    }, [])


 useImperativeHandle(ref, () => ({
     focus(){
         inputElementRef.current.focus()
     }
 }))

    useEffect(() =>{
        registerField({
            name: fieldName,
            ref: inputValueRef.current,
            path: 'value',
            setValue(ref, value ){
                inputValueRef.current.value = value
                inputElementRef.current.setNativePropos({text: value})
            },
            clearValue(){
                inputValueRef.current.value = ''
                inputElementRef.current.clear()                
            
            },
        })
    }, [fieldName, registerField])


    return(
        <>
     
        <TextInput
        isErrored={!!error}        
        style={ isFocused || isFilled ?  styles.inputActive : styles.inputInactive}
        ref={inputElementRef}
        defaultValue={defaultValue}
        onFocus={handleInputFocus}
        onBlur={handleInputBlur}
        onChangeText={(value) =>{
            inputValueRef.current.value = value
        }}
        {...rest}
        />

    </>
    )



}

const styles = StyleSheet.create({
inputInactive: {
    backgroundColor: '#FFF',
    width: 300,
    marginBottom: 15,
    color: '#222',
    fontSize: 18,
    borderRadius: 7,
    padding: 10,
    alignSelf:'center',
    borderWidth:3,
    borderColor:'#ff9000'
},
inputActive:{
    backgroundColor: '#FFF',
    width: 300,
    marginBottom: 15,
    color: '#222',
    fontSize: 18,
    borderRadius: 7,
    padding: 10,
    alignSelf:'center',
    borderWidth:3,
    borderColor:'#2ecc71'
},
inputError: {
    backgroundColor: '#FFF',
    width: 300,
    marginBottom: 15,
    color: '#222',
    fontSize: 18,
    borderRadius: 7,
    padding: 10,
    alignSelf:'center',
    borderWidth:3,
    borderColor:'#c53030'
},
})

export default forwardRef(Input)