//icones

//import temperatura from '../img/indicadores/temperatura.jpg'
//import umidade from '../img/indicadores/umidade.png'
//import amonia from '../img/indicadores/amonia.png'


const temperatura = 'https://st2.depositphotos.com/5266903/8982/v/950/depositphotos_89823200-stock-illustration-temperature-level-rounded-vector-icon.jpg'
const umidade = 'https://image.flaticon.com/icons/png/512/1582/1582784.png'
const amonia = 'https://img.icons8.com/plasticine/2x/test-tube.png'



const typeIcons = [
                   null,
                   temperatura,
                   umidade,
                   amonia]


export default typeIcons