import React from 'react';
import { View } from 'react-native';
import { WebView } from 'react-native-webview'

function Jhonny({ navigation }) {
    return <WebView style={{ flex: 1 }} source={{ uri: 'https://dadosagrocgti.shinyapps.io/indicadoresAgro' }} />
}

export default Jhonny;