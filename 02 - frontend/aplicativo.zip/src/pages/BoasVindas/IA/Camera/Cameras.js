import React from 'react';
import { View, Text } from 'react-native';

function Cameras() {
    return (

        <View>
            <Text> Hello Cameras</Text>
        </View>

    )
}

export default Cameras;