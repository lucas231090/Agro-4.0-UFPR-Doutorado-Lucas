import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity, Modal, Image } from 'react-native';
import { Camera } from 'expo-camera'
import { FontAwesome } from '@expo/vector-icons'
import * as Permissions from 'expo-permissions'
import * as MediaLibrary from 'expo-media-library'


function Pragas() {

    const camRef = useRef(null)
    const [type, setType] = useState(Camera.Constants.Type.back) // abrir camera trazeira
    const [hasPermission, setHaspermission] = useState(null)
    const [capturedPhoto, setCapturedPhoto] = useState(null)
    const [open, setOpen] = useState(false)

    useEffect(() => {

        (async () => {
            const { status } = await Camera.requestPermissionsAsync()
            setHaspermission(status === 'granted')
        })(),

            (async () => {
                const { status } = await Permissions.askAsync(Permissions.CAMERA_ROLL)
                console.log(status)
                setHaspermission(status === 'granted')
            })()
    }, [])



    if (hasPermission === null) {
        return <View />
    }

    if (hasPermission === false) {
        return <Text> Acesso negado </Text>
    }

    async function takePicture() {
        if (camRef) {
            const data = await camRef.current.takePictureAsync()
            setCapturedPhoto(data.uri)
            setOpen(true)
            console.log(data)
        }
    }

    async function savePicture() {
        const asset = await MediaLibrary.createAssetAsync(capturedPhoto)
            .then(() => {
                alert('Imagem salva com sucesso!!!')

            })
            .catch(error => {
                console.log('erro', error)
            })
    }

    function openAlbum(){
        const options ={
            title: 'Selecione uma foto',
            chooseFromLibrary
        }
    }

    return (
        <SafeAreaView style={styles.container}>

            <Camera
                style={styles.camera}
                type={type}
                ref={camRef}
            >
                <View style={{ flex: 1, backgroundColor: 'transparent', flexDirection: 'row' }}>
                    <TouchableOpacity
                        style={{ position: 'absolute', bottom: 20, left: 20 }}
                        onPress={() => {
                            setType(
                                type === Camera.Constants.Type.back
                                    ? Camera.Constants.Type.front
                                    : Camera.Constants.Type.back
                            )
                        }}
                    >
                        <FontAwesome name="rotate-right" size={30} color="#fff" />

                    </TouchableOpacity>
                </View>
            </Camera>
            <View style={{flexDirection:'row', backgroundColor:'#999'}}>
            <View style={{alignItems:'center', backgroundColor:'#cc0000', flex:1}}>
            <TouchableOpacity style={styles.buttom} onPress={takePicture}>
            
                <FontAwesome name="camera" size={23} color="#FFF" /> 
                <Text style={{color:'#fff'}}>Tirar foto</Text>
            </TouchableOpacity>
            </View>
            
            <View style={{alignItems:'center', backgroundColor:'#caac', flex:1}}>
            <TouchableOpacity style={styles.buttom} onPress={() => {}}>
                <FontAwesome name="photo" size={23} color="#FFF" />
                <Text style={{color:'#fff'}}>Álbum</Text>
            </TouchableOpacity>
            </View>
            </View>

            {capturedPhoto &&
                <Modal
                    animatedType='slide'
                    transparent={false}
                    visible={open}
                >
                    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', margin: 20 }}>

                        <View style={{ margin: 10, flexDirection: 'row' }}>
                            <TouchableOpacity style={{ margin: 10 }} onPress={() => setOpen(false)}>
                                <FontAwesome name="window-close" size={50} color='#FF0000' />
                            </TouchableOpacity>

                            <TouchableOpacity style={{ margin: 10 }} onPress={savePicture}>
                                <FontAwesome name="upload" size={50} color='#000' />
                            </TouchableOpacity>
                        </View>

                        <Image
                            style={{ width: '100%', height: 450, borderRadius: 30 }}
                            source={{ uri: capturedPhoto }}
                        />

                    </View>
                </Modal>
            }

        </SafeAreaView >
    )
}


export default Pragas;

const styles = StyleSheet.create({

    container: {
        flex: 1,
        justifyContent: 'center',
    },
    camera: {
        flex: 1,
    },
    buttom: {
        justifyContent: 'center',
        alignItems: 'center',
        margin: 10,
        borderRadius: 30,
        height: 25,

    }
})

