import React from "react";
import { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  StatusBar
} from "react-native";

import axios from 'axios'

import { AntDesign, Ionicons, Entypo, MaterialCommunityIcons, MaterialIcons, SimpleLineIcons, FontAwesome } from '@expo/vector-icons'

import InfoCard from "../APIWeather/InfoCard";

import CardAlcalinidade from '../../../components/cardIndicadores/CardAlcalinidade'
import CardTemperatura from '../../../components/cardIndicadores/CardTemperatura'
import CardUmidade from '../../../components/cardIndicadores/CardUmidade'

function Profile({ navigation }) {

  //const fazendaNome = navigation.getParam('techs') - criar uma nova rota para alocar as fazendas e assistir os videos do diego

  const [currentTemperature, setCurrentTemperature] = useState("27");

  const [location, setLocation] = useState("Curitiba/PR");
  const wind = "30";
  const humidity = "65";
  const temperatureMin = "10";
  const temperatureMax = "20";

  const [dhtTemperatura, setDhtTemperatura] = useState("--")

  const temperatura = () => {
    axios.get('http://192.168.25.16/dht11/temperatura').then( response => {
      setDhtTemperatura( dhtTemperatura => response.data)
      console.log(dhtTemperatura)
    })
  }
  
  const [dhtUmidade, setDhtUmidade] = useState('--')
  
  const umidade = () => {
      axios.get('http://192.168.25.16/dht11/umidade').then( response => {
        setDhtUmidade( dhtUmidade => response.data)
      console.log(dhtUmidade)
    })
  }

  return (
    <>
      <View style={styles.containerPainel}>   
        <View style={styles.viewPainel}>
          <View style={styles.hoje}>
          <Text style={styles.painel}>Hoje</Text>
          <Text style={styles.calendario}>Terça Feira, 17 de novembro de 2020 </Text>
          </View>
        <TouchableOpacity onPress={()=>{
          navigation.navigate('')
        }}>
          <Image
                    style={styles.settings}
                    source={{
                      uri:
                        "https://cdn4.iconfinder.com/data/icons/universal-line/614/1019_-_Edit_Profile-256.png",
                    }}
                  />
                  <Text style={{fontSize:10, marginRight:10, marginBottom:3, textAlign:'center'}}> Editar Perfil</Text>
        </TouchableOpacity>
        </View>

        <ScrollView>
        
        <View style={styles.controle}>
            <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https://cdn3.iconfinder.com/data/icons/gardening-smooth-vol-3/256/Soil_Ph_Meter-256.png",
                    
                    }
                  }
                  />                  
          <View style={styles.dashboard1}>                      
          <Text style={styles.titulo}>Alcalinidade do solo</Text>
          
          <View style={styles.grafico}>
          <CardAlcalinidade />
          </View>
          <View style={{flexDirection: 'row', justifyContent:'space-around'}}>          
          <Text style={styles.detalhes}>Última medição: <Text style={styles.ultimaMedicaoLaranja}>2.1</Text><Text style={{fontSize:20}}>pH</Text></Text>
          <View style={{alignSelf:'center', backgroundColor:'#42A5F5', marginTop:25, borderRadius:4}}>
          <TouchableOpacity>
          <View style={{flexDirection:'row', alignItems:'center'}}>
          <MaterialIcons name="sync" size={20} color="#fff" />
          <Text style={styles.medir}> Atualizar </Text>
          </View>
          </TouchableOpacity>
          </View>
          </View>
          <Text style={styles.maisInfo}>Níveis ideais entre <Text style={{color: '#2ECC71', fontWeight:'bold'}}>3.0</Text> e <Text style={{color:'#2ECC71', fontWeight:'bold'}}>6.8</Text>pH</Text>
          </View>
          </View>

          <View style={styles.controle}>
            <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https://cdn0.iconfinder.com/data/icons/50-gradening/512/Gardening_29-256.png",
                    
                    }
                  }
                  />                  
          <View style={styles.dashboard1}>                      
          <Text style={styles.titulo}>Umidade do solo</Text>
          
          <View style={styles.grafico}>
          <CardUmidade />
          </View>
          <View style={{flexDirection: 'row', justifyContent:'space-around'}}>          
          <Text style={styles.detalhes}>Última medição: <Text style={dhtUmidade < 55 ? styles.ultimaMedicaoVerde : styles.ultimaMedicaoVermelho }>{dhtUmidade}</Text><Text style={{fontSize:20}}>%</Text></Text>
          <View style={{alignSelf:'center', backgroundColor:'#42A5F5', marginTop:25, borderRadius:4}}>
          <TouchableOpacity onPress={() => setDhtUmidade(umidade)}>
          <View style={{flexDirection:'row', alignItems:'center'}}>
          <MaterialIcons name="sync" size={20} color="#fff" />
          <Text style={styles.medir}> Atualizar </Text>
          </View>
          </TouchableOpacity>
          </View>
          </View>
          <Text style={styles.maisInfo}>Níveis ideais entre <Text style={{color: '#2ECC71', fontWeight:'bold'}}>25</Text> e <Text style={{color:'#2ECC71', fontWeight:'bold'}}>55</Text>%</Text>
          </View>
          </View>

          <View style={styles.controle}>
            <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https://cdn3.iconfinder.com/data/icons/smart-home-67/64/humidity-mobilephone-mobile-save-water-256.png",
                    
                    }
                  }
                  />                  
          <View style={styles.dashboard1}>                      
          <Text style={styles.titulo}>Umidade do ar</Text>
          
          <View style={styles.grafico}>
          <CardUmidade />
          </View>
          <View style={{flexDirection: 'row', justifyContent:'space-around'}}>          
          <Text style={styles.detalhes}>Última medição: <Text style={dhtUmidade >= 55 ? styles.ultimaMedicaoVerde : styles.ultimaMedicaoVermelho }>{dhtUmidade}</Text><Text style={{fontSize:20}}>%</Text></Text>
          <View style={{alignSelf:'center', backgroundColor:'#42A5F5', marginTop:25, borderRadius:4}}>
          <TouchableOpacity onPress={() => setDhtUmidade(umidade)}>
          <View style={{flexDirection:'row', alignItems:'center'}}>
          <MaterialIcons name="sync" size={20} color="#fff" />
          <Text style={styles.medir}> Atualizar </Text>
          </View>
          </TouchableOpacity>
          </View>
          </View>
          <Text style={styles.maisInfo}>Níveis ideais entre <Text style={{color: '#2ECC71', fontWeight:'bold'}}>55</Text> e <Text style={{color:'#2ECC71', fontWeight:'bold'}}>99</Text>%</Text>
          </View>
          </View>

          <View style={styles.controle}>
            <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https://cdn3.iconfinder.com/data/icons/tools-125/64/83-256.png",
                    
                    }
                  }
                  />



          <View style={styles.dashboard1}>                      
          <Text style={styles.titulo}>Temperatura</Text>
          
          <View style={styles.grafico}>
          <CardTemperatura />
          </View>
          <View style={{flexDirection: 'row', justifyContent:'space-around'}}>          
          <Text style={styles.detalhes}>Última medição: <Text style={ dhtTemperatura >= 12 ? styles.ultimaMedicaoVerde : styles.ultimaMedicaoVermelho}>{dhtTemperatura}</Text><Text style={{fontSize:20}}>ºc</Text></Text>
          <View style={{alignSelf:'center', backgroundColor:'#42A5F5', marginTop:25, borderRadius:4}}>
          <TouchableOpacity onPress={() => setDhtTemperatura(temperatura)}>
          <View style={{flexDirection:'row', alignItems:'center'}}>
          <MaterialIcons name="sync" size={20} color="#fff" />
          <Text style={styles.medir}> Atualizar </Text>
          </View>
          </TouchableOpacity>
          </View>
          </View>
          <Text style={styles.maisInfo}>Níveis ideais entre <Text style={{color: '#2ECC71', fontWeight:'bold'}}>12</Text> e <Text style={{color:'#2ECC71', fontWeight:'bold'}}>28</Text>ºc</Text>
          </View>
          </View>
        </ScrollView>
        </View> 

      {/* INICIO API WEATHER*/}
      <View style={styles.info}>
        <Text style={styles.infoText}>
          O clima em{" "}
          <Text style={styles.location}>{location}</Text> hoje:
        </Text>
        <View style={styles.addtionalInfo}>
          <InfoCard title={"Chuva mm³:"} variable={wind} />
          <InfoCard title={"Umidade Relativa(%)"} variable={humidity} />
          <InfoCard title={"Min ºC"} variable={temperatureMin} />
          <InfoCard title={"Max ºC"} variable={temperatureMax} />
        </View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({

    containerPainel: {
    backgroundColor: "#f2f2f2",
    flex:3,
  },

  ///INICIO ESTILIZAÇÃO CARD PAINEL DE CONTROLE

  calendario: {
    fontSize:12,
    color: '#696969',
    alignSelf:'flex-end',
    marginLeft:10
  },

  viewPainel: { 
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'space-between',
    backgroundColor:'#fff',
    alignSelf:'center',
    marginTop:4,
    height:65,
    width:'95%',
    borderRadius:10,
    shadowColor: "#c7c7c7",
shadowOffset: {
	width: 0,
	height: 5,
},
shadowOpacity: 0.34,
shadowRadius: 6.27,

elevation: 10,
    
  },

  painel:{
    color: '#000',
    fontSize:25,
    marginLeft:10,
    fontWeight:'bold',
  },
  
  dashboard1:{
    backgroundColor:'#fff',
    marginLeft: -30,
    marginTop:25,
    height:170,
    width:320,
    borderRadius:12,
    shadowColor: "#c7c7c7",
    shadowOffset: {
  	width: 0,
    height: 5,
},
shadowOpacity: 0.34,
shadowRadius: 6.27,    
},

controle:{
  backgroundColor:'#f2f2f2',
  flexDirection: 'row',
  marginLeft: 15,
},
settings: {
  width: 40,
  height: 40,
  marginRight:10
},
icon: {
  marginTop:10,
    width: 60,
    height: 100,
    zIndex:1   
  },

   titulo: {
    fontWeight: "bold",
    fontSize: 14,
    marginTop:15,
    marginLeft:38,
    marginRight:5
  },

  detalhes: {
    fontSize:15,
    textAlign:"justify",
    marginTop:25,
    color: '#696969'
  },

  medir: {
    fontSize:14,
    color: '#fff',
  },

  grafico: {
    marginTop:10,
    marginLeft:60,

  },

  maisInfo: {
    fontSize:12,
    color: '#696969',
    alignSelf:'flex-end',
    marginLeft:38,
    marginRight:10,
    marginTop:15,
  },

  //Inicio do card da API Weather

  info: {
    alignItems: "center",
    width: "100%",
    backgroundColor: "#4169E1",
  },

  infoText: {
    color: "#FFF",
    fontSize: 12,
    fontWeight: "bold",
    alignSelf: "center",
  },

  addtionalInfo: {
    flexDirection: "row",
    flexWrap: "wrap",
  },

  location:{
    color: '#FFF'
  },

  ultimaMedicaoVerde:{
    fontWeight:'bold',
     fontSize:25,
      color:'#2ECC71'
  },

  ultimaMedicaoAmarelo:{
    fontWeight:'bold',
     fontSize:25,
      color:'#FFEE58'
  },

  ultimaMedicaoLaranja:{
    fontWeight:'bold',
     fontSize:25,
      color:'#E67E22'
  },

  ultimaMedicaoVermelho:{
    fontWeight:'bold',
     fontSize:25,
      color:'#cc0000'
  },




});

export default Profile;

//#33ff77
