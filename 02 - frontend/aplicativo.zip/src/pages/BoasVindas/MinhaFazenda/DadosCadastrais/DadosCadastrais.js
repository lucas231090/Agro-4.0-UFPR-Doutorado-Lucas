import React from 'react';
import { View, Text } from 'react-native';

function DadosCadastrais() {
    return (

        <View>
            <Text> Hello Dados Cadastrais</Text>
        </View>

    )
}

export default DadosCadastrais;