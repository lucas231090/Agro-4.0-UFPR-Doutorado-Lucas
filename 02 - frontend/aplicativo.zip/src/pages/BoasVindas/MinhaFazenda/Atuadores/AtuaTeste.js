import React from "react";
import { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  Switch,
  Alert,
  Image,
  TouchableOpacity,
  ScrollView
} from "react-native";

import { AntDesign, Ionicons, Entypo, MaterialCommunityIcons, MaterialIcons, SimpleLineIcons, FontAwesome } from '@expo/vector-icons'

import axios from "axios"

//import { AntDesign, Ionicons, Entypo, MaterialCommunityIcons, MaterialIcons, SimpleLineIcons, FontAwesome } from '@expo/vector-icons'


function Profile({ navigation }) {

  const [isEnable, setIsEnable] = useState(false)
    
  const alternarSwitch = () => {
    setIsEnable(previousState => !previousState)    
  }
  

  const [isEnable2, setIsEnable2] = useState(false)
    
  const alternarSwitch2 = () => {
    setIsEnable2(previousState => !previousState)    
  }


const alternaLed = () => {

    if (isEnable == false) { 
    axios.get('http://192.168.25.16/on').then(response => {
      console.log('led ligada com sucesso!!!')
    })
  }
    
  else{
    axios.get('http://192.168.25.16/off').then(response => {
      console.log('led apagada')
  })
}}

const alternaLed2 = () => {

  if (isEnable2 == false) { 
  axios.get('http://192.168.25.16/onVerde').then(response => {
    console.log('led ligada com sucesso!!!')
  })

}
  
else{
  axios.get('http://192.168.25.16/offVerde').then(response => {
    console.log('led apagada')
})

}}

const [dhtTemperatura, setDhtTemperatura] = useState("--")

const temperatura = () => {
  axios.get('http://192.168.25.16/dht11/temperatura').then( response => {
    setDhtTemperatura( dhtTemperatura => response.data)
    console.log(dhtTemperatura)
  })
}

const [dhtUmidade, setDhtUmidade] = useState('--')

const umidade = () => {
    axios.get('http://192.168.25.16/dht11/umidade').then( response => {
      setDhtUmidade( dhtUmidade => response.data)
    console.log(dhtUmidade)
  })
}


  return (
    <>     

    <ScrollView>    
          <Text style={styles.titulo}>Led Vermelho</Text>          
          
          <View style={{flexDirection: 'row', justifyContent:'space-around'}}>          
                <Text style={ isEnable ? styles.ON : styles.OFF}> {isEnable ? 'LIGADO'  : 'DESLIGADO'}</Text>        
          <Switch
          onValueChange={alternarSwitch}
          value={isEnable}
          onChange={alternaLed}
          />
                
          </View>

          <Text style={styles.titulo}>Led Verde</Text>          
          
          <View style={{flexDirection: 'row', justifyContent:'space-around'}}>          
                <Text style={ isEnable2 ? styles.ON : styles.OFF}> {isEnable2 ? 'LIGADO'  : 'DESLIGADO'}</Text>        
          <Switch
          onValueChange={alternarSwitch2}
          value={isEnable2}
          onChange={alternaLed2}
          />        
          </View>
                        
          <Text style={styles.titulo}>Umidade</Text>
          <View style={{flexDirection: 'row', justifyContent:'space-around'}}>          
          <Text style={styles.detalhes}>Medida: <Text style={{fontSize:50, fontWeight:'bold', color: '#4b8b3b'}}> {dhtUmidade}</Text><Text style={{fontSize:35}}>%</Text></Text>
          <View style={{alignSelf:'center', backgroundColor:'#2ecc71', marginTop:25, borderRadius:4}}>
          <TouchableOpacity onPress={() => setDhtUmidade(umidade)}>
          <View style={{flexDirection:'row', alignItems:'center'}}>
          <MaterialIcons name="sync" size={45} color="#fff" />
          
          </View>
          </TouchableOpacity>
          </View>
          </View>
          
    

                            
          <Text style={styles.titulo}>Temperatura</Text>
   
          <View style={{flexDirection: 'row', justifyContent:'space-around'}}>          
          <Text style={styles.detalhes}>Medida: <Text style={{fontSize:50, fontWeight:'bold', color: '#ff4e50'}}> {dhtTemperatura}</Text><Text style={{fontSize:35}}>ºc</Text></Text>
          <View style={{alignSelf:'center', backgroundColor:'#2ecc71', marginTop:25, borderRadius:4}}>
          <TouchableOpacity onPress={() => setDhtTemperatura(temperatura)}>
          <View style={{flexDirection:'row', alignItems:'center'}}>
          <MaterialIcons name="sync" size={45} color="#fff" />
         
          </View>
          </TouchableOpacity>
          </View>
          </View>

          </ScrollView>
        
    </>
  );
}

const styles = StyleSheet.create({


titulo: {
    fontWeight: "bold",
    fontSize: 25,
    marginTop:15,
    marginLeft:25,
  },

  ON: {
    fontSize:20,
    textAlign:"justify",
    marginTop:15,
    color: '#2ecc71',
    fontWeight:'bold'

  },

  OFF: {
    fontSize:20,
    textAlign:"justify",
    marginTop:15,
    color: '#ff4040',
    fontWeight:'bold'
  },

  controle:{
    marginLeft: 25,
  },

  detalhes: {
    fontSize:15,
    textAlign:"justify",
    marginTop:25,
    color: '#696969'
  },


});

export default Profile;

