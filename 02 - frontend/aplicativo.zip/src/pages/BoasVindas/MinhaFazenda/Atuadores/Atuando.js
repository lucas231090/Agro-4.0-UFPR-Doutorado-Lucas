import React from "react";
import { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  Switch,
} from "react-native";

import axios from "axios"



//import { AntDesign, Ionicons, Entypo, MaterialCommunityIcons, MaterialIcons, SimpleLineIcons, FontAwesome } from '@expo/vector-icons'


function Profile({ navigation }) {

  //const fazendaNome = navigation.getParam('techs') - criar uma nova rota para alocar as fazendas e assistir os videos do diego

  const [currentTemperature, setCurrentTemperature] = useState("27");

  const [location, setLocation] = useState("Curitiba/PR");
  const wind = "30";
  const humidity = "65";
  const temperatureMin = "10";
  const temperatureMax = "20";

  const [isEnable, setIsEnable] = useState(false)

  const [isEnable2, setIsEnable2] = useState(false)

  const [isEnable3, setIsEnable3] = useState(false)

  const [isEnable4, setIsEnable4] = useState(false)

 const [ligaLed, setLigaLed] = useState(false)
 
  const alternarSwitch = () => {
    setIsEnable(previousState => !previousState)
        
  }

  const alternarSwitch2 = () => {
    setIsEnable2(previousState => !previousState)
        
  }

  const alternarSwitch3 = () => {
    setIsEnable3(previousState => !previousState)
        
  }

  const alternarSwitch4 = () => {
    setIsEnable4(previousState => !previousState)
        
  }

  const alternaLed = () => {

    if (setLigaLed !== false) { 
    axios.get('http://192.168.25.16/on').then(response => {
      console.log('led ligada com sucesso!!!')
    })
  }
  }
    


  return (
    <>
      <View style={styles.containerPainel}>   
      
        <ScrollView>
        
        <View style={styles.controle}>
            <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https://cdn1.iconfinder.com/data/icons/fan-and-air-conditioning-filled/64/fan_Air_Ventilation-31-256.png",
                    
                    }
                  }
                  />                  
          <View style={styles.dashboard1}>                      
          
       
          <Text style={styles.titulo}>Ventilação da Granja 01</Text>
                    
          <View style={{flexDirection: 'row', justifyContent:'space-around'}}>          
          
                <Text style={ isEnable ? styles.ON : styles.OFF}> {isEnable ? 'LIGADO'  : 'DESLIGADO'}</Text>        
         
          <View style={{flexDirection:'row', alignItems:'center'}}>
         
          <Switch
          onValueChange={alternarSwitch}
          value={isEnable}
          onChange={ligaLed ? alternaLed : alternaLed}
          
          />
          </View>         
          </View>
          
          <Text style={styles.maisInfo}>Temperatura: <Text style={{color: '#2ecc71', fontWeight:'bold'}}>29</Text> ºC</Text>


          </View>
          </View>

          <View style={styles.controle}>
            <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https://cdn1.iconfinder.com/data/icons/fan-and-air-conditioning-filled/64/fan_Air_Ventilation-31-256.png",
                    
                    }
                  }
                  />                  
          <View style={styles.dashboard1}>                      
          <Text style={styles.titulo}>Ventilação da Granja 02</Text>
          <View style={{flexDirection: 'row', justifyContent:'space-around'}}>          
         
          <Text style={ isEnable2 ? styles.ON : styles.OFF}> {isEnable2 ? 'LIGADO'  : 'DESLIGADO'}</Text>
       

          <View style={{flexDirection:'row', alignItems:'center'}}>
          
          <Switch
          onValueChange={alternarSwitch2}
          value={isEnable2}
          />
          
          </View>
          
       
          </View>
          <Text style={styles.maisInfo}>Temperatura: <Text style={{color: '#2ecc71', fontWeight:'bold'}}>29</Text> ºC</Text>

          </View>
          </View>

          <View style={styles.controle}>
            <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https://cdn1.iconfinder.com/data/icons/internet-of-things-126/64/Artboard_7iot-256.png",
                    
                    }
                  }
                  />



          <View style={styles.dashboard1}>                      
          <Text style={styles.titulo}>Sistema de Iluminação</Text>
          <View style={{flexDirection: 'row', justifyContent:'space-around'}}> 

           <Text style={isEnable3 ? styles.ON : styles.OFF}>{isEnable3 ? 'LIGADO'  : 'DESLIGADO'}</Text> 
         
          <View style={{flexDirection:'row', alignItems:'center'}}>
         
          <Switch
          onValueChange={alternarSwitch3}
          value={isEnable3}
          />
          
          </View>

          </View>
          </View>      
          </View>

          <View style={styles.controle}>
            <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https://cdn2.iconfinder.com/data/icons/internet-of-things-flat/64/40-Smart_farm-256.png",
                    
                    }
                  }
                  />



          <View style={styles.dashboard1}>                      
          <Text style={styles.titulo}>Sistema de Irrigação Talhão 01</Text>
          <View style={{flexDirection: 'row', justifyContent:'space-around'}}>          
          <Text style={ isEnable4 ? styles.ON : styles.OFF}> {isEnable4 ? 'LIGADO'  : 'DESLIGADO'}</Text> 
            <View style={{flexDirection:'row', alignItems:'center'}}>
          
            <Switch
          onValueChange={alternarSwitch4}
          value={isEnable4}
          /> 

          </View>
          </View>
          <Text style={styles.maisInfo}>Umidade do solo: <Text style={{color: '#cc0000', fontWeight:'bold'}}>45</Text> %</Text>
          
          </View>      
          </View>


        </ScrollView>
        </View> 

    </>
  );
}

const styles = StyleSheet.create({

    containerPainel: {
    backgroundColor: "#f2f2f2",
    flex:3,
  },
  
  dashboard1:{
    backgroundColor:'#fff',
    marginLeft: -30,
    marginTop:25,
    height:120,
    width:'75%',
    borderRadius:12,
    shadowColor: "#c7c7c7",
    shadowOffset: {
  	width: 0,
    height: 5,
},
shadowOpacity: 0.34,
shadowRadius: 6.27,    
},

controle:{
  backgroundColor:'#f2f2f2',
  flexDirection: 'row',
  marginLeft: 15,
},

icon: {
  marginTop:25,
    width: 100,
    height: 100,
    zIndex:1   
  },

   titulo: {
    fontWeight: "bold",
    fontSize: 14,
    marginTop:15,
    marginLeft:38,
    marginRight:5
  },

  ON: {
    fontSize:20,
    textAlign:"justify",
    marginTop:15,
    color: '#2ecc71',
    fontWeight:'bold'

  },

  OFF: {
    fontSize:20,
    textAlign:"justify",
    marginTop:15,
    color: '#ff4040',
    fontWeight:'bold'
  },

  medir: {
    fontSize:14,
    color: '#fff',
  },
  maisInfo: {
    fontSize:12,
    color: '#696969',
    alignSelf:'flex-start',
    marginLeft:38,
    marginRight:10,
    marginTop:15,
  },


});

export default Profile;

//#33ff77
