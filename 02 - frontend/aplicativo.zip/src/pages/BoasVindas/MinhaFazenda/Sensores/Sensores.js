import React, { useState } from "react";

import {
  SafeAreaView,
  TextInput,
  Text,
  StyleSheet,
  Button,
} from "react-native";

// import TcpSocket from 'react-native-tcp-socket';
//const [hasConnection, setHasConnection] = useState(true);

function Sensores() {
  const [hasConnection, setHasConnection] = useState(false);
  
  const [con, setCon] = useState(null);
  const [url, setUrl] = useState("");
  const [port, setPort] = useState(23);
  const [command, setCommand] = useState("");

  const handleConnectButton = () => {
    if (url != "") {
      let client = TcpSocket.createConnection({ url, port });

      client.on("close", () => {
        setHasConnection(false);
      });

      client.on("error", (error) => {
        alert(error);
      });

      client.on("data", (data) => {
        let response = Buffer.from(data).toString();

        alert(response);
      });

      setHasConnection(true);
      setCon(client);
    }
  };

  const handleCommandButton = () => {
    if (hasConnection) {
      con.write(command);
      setCommand("");
    }
  };

  const handleCloseButton = () => {
    if (hasConnection) {
      con.destroy();
    }
  };

  const handlePingCommand = () =>{
    if(hasConnection){
      con.write("ping")
    }
  }

  return (
    <SafeAreaView style={styles.main}>
      {hasConnection && (
        <>
          <Text>
            {" "}
            Conectado a {url}:{port}{" "}
          </Text>

          <Text style={styles.title}>Digite um comando:</Text>
          <TextInput
            style={styles.input}
            autoCorrect={false}
            value={command}
            onChangeText={(v) => setCommand(v)}
          />
          <Button title="Enviar Comando" onPress={handleCommandButton} />

          <Button title="Encerrar conexão" onPress={handleCloseButton} />

          <Button title="Testar Ping" onPress={handlePingCommand} />
        </>
      )}

      {hasConnection == false && (
        <>
          <Text style={styles.title}> Qual o IP do arduino? </Text>
          <TextInput
            style={styles.input}
            keyboardType="numeric"
            value={url}
            onChangeText={(v) => setUrl(v)}
          />

          <Button title="Conectar" onPress={handleConnectButton} />
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  main: {
    flex: 1,
    alignItems: "center",
  },
  title: {
    fontWeight: "bold",
    fontSize: 20,
    marginTop: 20,
    padding: 10,
  },
  input: {
    width: 300,
    fontSize: 22,
    padding: 15,
    backgroundColor: "#fff",
  },
});

export default Sensores;
