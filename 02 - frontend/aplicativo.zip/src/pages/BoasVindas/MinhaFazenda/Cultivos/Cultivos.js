import React from 'react';
import { View, Text, ScrollView } from 'react-native';

import CardTemperatura from "../../../../components/cardIndicadores/Indicadores&IoT/Temperatura"
import CardUmidade from '../../../../components/cardIndicadores/Indicadores&IoT/Umidade'
import CardAmonia from '../../../../components/cardIndicadores/Indicadores&IoT/Amonia'

function Cultivos() {
   
    return (
        <ScrollView>
        <View>
           
           <CardTemperatura />
            
        </View>
        </ScrollView>
        

    )
}

export default Cultivos;