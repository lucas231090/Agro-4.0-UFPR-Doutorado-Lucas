import React from "react";
import {
  View,
  StyleSheet,
  Image,
  Text,
  TouchableOpacity,
  ScrollView,
  Button,
} from "react-native";

//import date from 'date-fns'

import { useAuth } from "../../../hooks/auth";

function Index({ navigation }) {
  
  const { signOut } = useAuth();



  return (
    <>
      <View style={{ flex: 1, backgroundColor:'#fff' }}>
        <View style={{flexDirection:'row', justifyContent:'space-between'}}>
        <Text style={styles.BoasVindas}> Ola, fulano</Text>
        <Button title="Sair" onPress={signOut}/>
        </View>
        <Text> O tempo em curitiba está:</Text>

        <ScrollView>
          
        
          <View>
              <TouchableOpacity
                onPress={() => {
                  navigation.navigate("Profile");
                }}
                style={styles.btnSubmit}
              >
                <View style={styles.menuBox}>
                  <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https://cdn0.iconfinder.com/data/icons/streamline-emoji-1/48/138-man-farmer-2-256.png",
                    }}
                  />
                  <Text style={styles.info}>Meu Perfil</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  navigation.navigate("IoT");
                }}
                style={styles.btnSubmit}
              >
                <View style={styles.menuBox}>
                  <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https://cdn1.iconfinder.com/data/icons/artificial-intelligence-flat-style-1/128/Artificial_Intelligence_in_Agriculture_-_Flat_Style-15-256.png",
                    }}
                    //style={styles.icon}
                    //source={require("/Projetos/agro/app/src/img/fusao.png")}

                    //https://cdn3.iconfinder.com/data/icons/colorful-electronic-parts/108/electronicparts-20-512.png
                    //https://cdn4.iconfinder.com/data/icons/colorful-electronic-parts/108/circuitdiagram_full_of_color2-43-256.png
                    //https://cdn0.iconfinder.com/data/icons/smartfarm-1/64/monitor-control-technology-plants-smart_farm-farm-weather-256.png
                  />
                  <Text style={styles.info}>Indicadores & IoT</Text>
                </View>
              </TouchableOpacity>
            </View>

            <View style={styles.linhas}>
              <TouchableOpacity
                onPress={() => {
                  navigation.navigate("Cameras");
                }}
                style={styles.btnSubmit}
              >
                <View style={styles.menuBox}>
                  <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https://cdn4.iconfinder.com/data/icons/smart-city-vol-1-1/32/video_camera_smart_city_device_security_saftey-256.png",
                    }}
                  />
                  <Text style={styles.info}>Câmeras em tempo real </Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  navigation.navigate("Pragas");
                }}
                style={styles.btnSubmit}
              >
                <View style={styles.menuBox}>
                  <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https:cdn1.iconfinder.com/data/icons/artificial-intelligence-115/100/image_binary_code_color_system_digital_robotic-256.png",
                      //https://cdn3.iconfinder.com/data/icons/cloud-computing-66/66/47-256.png
                    }}
                  />
                  <Text style={styles.info}>Processamento de Imagem</Text>
                </View>
              </TouchableOpacity>
            </View>

            <View style={styles.linhas}>
              <TouchableOpacity
                onPress={() => {
                  navigation.navigate("Main");
                }}
                style={styles.btnSubmit}
              >
                <View style={styles.menuBox}>
                  <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https://cdn3.iconfinder.com/data/icons/travel-and-places-2-1/32/140-256.png",
                    }}
                  />
                  <Text style={styles.info}>Mapa das Fazendas</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  navigation.navigate("Suporte");
                }}
                style={styles.btnSubmit}
              >
                <View style={styles.menuBox}>
                  <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https://cdn1.iconfinder.com/data/icons/education-and-science-13/32/education_knowledge_growth-256.png",
                    }}
                  />
                  <Text style={styles.info}>Guias sobre o Agronegócio 4.0</Text>
                </View>
              </TouchableOpacity>
            </View>

            <View style={styles.linhas}>
              <TouchableOpacity
                onPress={() => {
                  navigation.navigate("Jhonny");
                }}
                style={styles.btnSubmit}
              >
                <View style={styles.menuBox}>
                  <Image
                    style={styles.icon}
                    source={{
                      uri: "https://img.icons8.com/officexs/72/brazil.png",
                    }}
                  />
                  <Text style={styles.info}>Indicadores Nacionais</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  navigation.navigate("Suporte");
                }}
                style={styles.btnSubmit}
              >
                <View style={styles.menuBox}>
                  <Image
                    style={styles.icon}
                    source={{
                      uri:
                        "https://cdn2.iconfinder.com/data/icons/home-office-13/512/support_technical_laptop_work_chat-256.png",
                    }}
                  />
                  <Text style={styles.info}>Suporte</Text>
                </View>
              </TouchableOpacity>
            </View>
            <View style={styles.linhas}>
            <TouchableOpacity
              onPress={() => {
                navigation.navigate("Sobre");
              }}
              style={styles.btnSubmit}
            >
              <View style={styles.menuBox}>
                <Image
                  style={styles.icon}
                  source={{
                    uri: "https://img.icons8.com/clouds/72/about.png",
                  }}
                />
                <Text style={styles.info}>Sobre o Projeto</Text>
              </View>
            </TouchableOpacity>
          </View>
        </ScrollView>

          <View>
          <View style={{ backgroundColor: "#4169e1" }}>
            <Text style={{ fontSize: 12, textAlign: "center", color: "#fff" }}>
              Versão beta 0.1
            </Text>
          </View>
        </View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  BoasVindas: {
    marginTop: 10,
    color: "#cc0000",
    textAlign: "center",
    justifyContent: "center",
    fontSize: 20,
    fontWeight: "bold",
    alignContent:'space-around'
  },

  textInfo: {
    fontSize: 18,
    marginTop: 20,
    color: "#696969",
  },
  menuBox: {
    backgroundColor: "#FFF",
    width: '95%',
    height: 65,
    alignItems: "center",
    justifyContent: "flex-start",
    margin: 10,
    shadowColor: "black",
    shadowOpacity: 0.7,
    shadowOffset: {
      height: 5,
      width: -2,
    },
    paddingLeft:25,
    elevation: 4,
    flexDirection:'row',
    borderRadius:15
  },
  icon: {
    width: 50,
    height: 50,
  },
  info: {
    fontSize: 16,
    color: "#000",
    fontWeight:'bold'
  },

});

export default Index;

//#20720d
