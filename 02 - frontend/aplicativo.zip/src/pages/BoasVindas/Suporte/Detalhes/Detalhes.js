import React from 'react';
import { View, Text, StyleSheet, Linking } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { Feather, Ionicons } from '@expo/vector-icons'
import * as MailComposer from 'expo-mail-composer'


function Detalhes() {
    
   const message = 'Houve um alagamento na plantação e acho que estragou o módulo do sensor'
   
    function sendMail(){
        MailComposer.composeAsync({
            subject: 'Defeito sensor',
            recipients: ['souza.lucasj@ufpr.br'],
            body: message,
        })
    }
    
    function sendWhatsapp(){
        Linking.openURL(`whatsapp://send?phone=554192751973&text=${message}`)
    }
    
    return (

        <View style={styles.container}>
            <View style={styles.incident}>

                <Text style={[styles.incidentPropriety, {marginTop:0}]}>Fazenda</Text>
                <Text style={styles.incidentValue}>Agro 4.0 UFPR</Text>

                <Text style={styles.incidentPropriety}>Assunto</Text>
                <Text style={styles.incidentValue}>Defeito sensor</Text>

                <Text style={styles.incidentPropriety}>Descrição</Text>
                <Text style={styles.incidentValue}>Houve um alagamento na plantação e acho que estragou o modulo do sensor</Text>
            </View>

            <View style={styles.contactBox}>
                <Text style={styles.heroTitle}>Escolha o canal de atendimento</Text>
                <Text style={styles.heroTitle}></Text>

                <View style={styles.actions}>
                    <TouchableOpacity
                        style={styles.action}
                        onPress={sendWhatsapp}>
                        <Text style={styles.actionText}>WhatsApp</Text>
                        <Ionicons name="logo-whatsapp" size={18} color='#FFF' />
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={styles.action}
                        onPress={sendMail}>
                        <Text style={styles.actionText}>E-mail</Text>
                        <Feather name="mail" size={18} color='#FFF' />
                    </TouchableOpacity>

                </View>


            </View>
        </View>

    )
}


const styles = StyleSheet.create({

    container: {
        flex: 1,
        paddingHorizontal: 6,
    },

    incident: {
        padding: 24,
        borderRadius: 8,
        backgroundColor: '#FFF',
        marginBottom: 12,
        marginTop: 12
    },

    incidentPropriety: {
        fontSize: 14,
        color: '#3b8927',
        fontWeight: 'bold',
        marginTop: 24

    },

    incidentValue: {
        fontSize: 16,
        color: '#737380'
    },

    contactBox: {
        padding: 24,
        borderRadius: 8,
        backgroundColor: '#FFF',
        marginBottom: 12,        
    },

    heroTitle: {
        fontWeight:'bold',
        fontSize:20,
        color:'#13131a',
        lineHeight:30
        
    },

    heroDescription: {
        fontSize:15,
        color:'#737380',
        marginTop:16
    },

    actions: {
        marginTop:16,
        flexDirection:'row',
        justifyContent:'space-between'

    },

    action: {
        backgroundColor:'#2ecc71',
        borderRadius:8,
        height:50,
        width: 120,
        justifyContent:'center',
        alignItems:'center'
    },

    actionText: {
        color:'#FFF',
        fontSize:15,
        fontWeight:'bold'
        
    }

})


export default Detalhes;