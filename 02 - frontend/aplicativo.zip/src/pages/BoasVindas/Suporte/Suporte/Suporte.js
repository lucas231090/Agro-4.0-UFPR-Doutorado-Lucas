import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import { Feather } from '@expo/vector-icons'



function Suporte({navigation}) {
 
    return (
        <>
            <View>
                <Text style={styles.title}>
                    BEM VINDO, Fulano
                </Text>
                <Text style={styles.description}>Chamados em aberto:</Text>
            </View>

            <FlatList
                data={[1, 2, 3, 4, 5, 6, 7, 8]}
                style={styles.incidentList}
                keyExtractor={incident => String(incident)}
                renderItem={() => (

                    <View style={styles.incident}>
                        <Text style={styles.incidentProperty}>Fazenda:</Text>
                        <Text style={styles.incidentValue}>UFPR 4.0 agro</Text>

                        <Text style={styles.incidentProperty}>Assunto:</Text>
                        <Text style={styles.incidentValue}>Defeito sensor</Text>

                        <Text style={styles.incidentProperty}>Breve descrição</Text>
                        <Text style={styles.incidentValue}>Teve um alagamento na ultima chuva, acho que estragou o sensor, não funciona</Text>

                        <TouchableOpacity style={styles.detailsButton}
                            onPress={() => {navigation.navigate('Detalhes')
                            }}>

                            <Text style={styles.detailsButtonText}>Ver mais</Text>
                            <Feather name="file-plus" size={18} color='#3b8927' />
                        </TouchableOpacity>
                    </View>

                )}
            />
         

        
        </>
    )
}

const styles = StyleSheet.create({

    title: {
        fontSize: 16,
        marginTop: 5,
        color: '#13131a',
        fontWeight: 'bold',
    },

    description: {
        paddingTop: 1,
        fontSize: 14,
        lineHeight: 24,
        color: '#737380',
        textAlign: 'justify'
    },

    incidentList: {
        marginTop: 5
    },

    incident: {
        padding: 24,
        borderRadius: 8,
        backgroundColor: '#FFF',
        marginBottom: 16,
    },

    incidentProperty: {
        fontSize: 14,
        color: '#3b8927',
        fontWeight: 'bold'
    },

    incidentValue: {
        fontSize: 16,
        marginBottom: 12,
        color: '#737380'
    },

    detailsButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end'
    },

    detailsButtonText: {
        color: '#000',
        fontSize: 14,
        fontWeight: 'bold'
    }
})


export default Suporte;