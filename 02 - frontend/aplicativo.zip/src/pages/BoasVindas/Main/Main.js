import React, { useEffect, useState } from 'react';
import {
    View,
    StyleSheet,
    Image,
    Text,
    TextInput,
    TouchableOpacity
} from 'react-native';
import MapView, { Marker, Callout } from 'react-native-maps'
//import { requestPermissionsAsync, getCurrentPositionAsync } from 'expo-location'
import { requestForegroundPermissionsAsync, getCurrentPositionAsync } from 'expo-location'
import { MaterialIcons } from '@expo/vector-icons'

import api from '/Projetos/agro/app/src/services/api';

import { connect, disconnect, subscribeToNewFarms } from '/Projetos/agro/app/src/services/socket';

function Main({ navigation }) {

    const [farms, setFarms] = useState([]);
    const [currentRegion, setCurrentRegion] = useState(null)
    const [cultivos, setCultivos] = useState('');
    

    useEffect(() => {
        async function loadInitialPosition() {
            const { granted } = await requestForegroundPermissionsAsync()

            if (granted) {
                const { coords } = await getCurrentPositionAsync({
                    enableHighAccuracy: true,
                })

                const { latitude, longitude } = coords

                setCurrentRegion({
                    latitude,
                    longitude,
                    latitudeDelta: 0.01,
                    longitudeDelta: 0.01,
                })
            }
        }

        loadInitialPosition()
    }, [])


    useEffect(() => {
        subscribeToNewFarms(farm => setFarms([...farms, farm]));
      }, [farms]);
    
      function setupWebsocket() {
        disconnect();
    
        const { latitude, longitude } = currentRegion;
    
        connect(
          latitude,
          longitude,
          cultivos,
        );
      }
    
      async function loadFarms() {

        const { latitude, longitude } = currentRegion;
    
        const response = await api.get('/search', {
            params: {
            latitude,
            longitude,
            cultivos,
          }
        });
        
        setFarms(response.data.farms);
        
        setupWebsocket();
      }

     
    
      function handleRegionChanged(region) {
          console.log(region)
        setCurrentRegion(region);
      }


    if (!currentRegion) {
        return (null)
    }

    // navigation.navigate('Profile', {techs: dev.techs} - dentro do callout onPress


    return (
        <>
            <MapView 
            onRegionChangeComplete={handleRegionChanged} 
            initialRegion={currentRegion} 
            style={styles.map}
            >


                
            {farms.map(farm => (
                 <Marker 
                     key={farm._id}
                    coordinate={{ 
                     longitude: farm.location.coordinates[0],
                     latitude: farm.location.coordinates[1], 
                      }}
               >    
                    
                    <Image style={styles.avatar} source={{ uri: farm.avatar_url }} />
                   
                    <Callout onPress={() => { } }>
                        <View style={styles.callout}>
                        <Text style={styles.fazendaNome}>{farm.fazenda}</Text>
                        <Text style={styles.fazendaBio}>{farm.bio}</Text>
                        <Text style={styles.fazendaProd}>{farm.cultivos.join(', ')}</Text>
                        </View>
                    </Callout>
                </Marker>
            ))}

            </MapView>


            <View style={styles.searchForm}>
                <TextInput
                    style={styles.searchInput}
                    placeholder="Buscar Fazenda por cultivos"
                    placeholderTextColor="#999"
                    autoCapitalize="words"
                    autoCorrect={false}
                    value={cultivos}
                    onChangeText={setCultivos}
                />

                <TouchableOpacity onPress={loadFarms} style={styles.loadBotton}>
                    <MaterialIcons name="my-location" size={20} color="#FFF" />
                </TouchableOpacity>
                

            </View>



        </>
    )
}


const styles = StyleSheet.create({
    map: {
        flex: 1
    },

    avatar: {
        width: 54,
        height: 54,
        borderRadius: 10,
        borderWidth: 4,
        borderColor: '#8E4Dff'
    },

    callout: {
        width: 260,
        borderRadius:10,
        flex:1
    },
    fazendaNome: {
        fontWeight: 'bold',
        fontSize: 16,
        padding:3,
        textAlign: "justify"
    },
    fazendaBio: {
        color: '#666',
        marginTop: 5,
        padding:3,
        textAlign: "justify"
    },
    fazendaProd: {
        marginTop: 5,
        padding:3,
        fontSize:12,
        textAlign: "justify"
    },
    searchForm: {
        position: 'absolute', // pra ficar em cima do mapa
        top: 20,
        left: 20,
        right: 20,
        zIndex: 5,
        flexDirection: 'row'
    },
    searchInput: {
        flex: 1,
        height: 45,
        backgroundColor: '#FFF',
        borderRadius: 25,
        paddingHorizontal: 10,
        borderColor: '#333',
        fontSize: 15,
        shadowColor: '#000',
        shadowOpacity: 0.2,
        textShadowOffset: {
            width: 4,
            height: 4,
        },
        elevation: 2,
    },
    loadBotton: {
        width: 45,
        height: 45,
        backgroundColor: '#009f00',
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 10,

    },


})

export default Main;


//#8E4Dff

