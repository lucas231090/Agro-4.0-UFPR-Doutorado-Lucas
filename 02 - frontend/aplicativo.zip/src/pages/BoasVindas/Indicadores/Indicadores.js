import React, { Component, useState, useEffect } from "react";
import {ScrollView,StyleSheet, TouchableOpacity, Text, View } from "react-native";
//import {format} from 'date-fns'

//import CardTemperatura from "../../../components/cardIndicadores/Indicadores&IoT/Temperatura"
//import CardUmidade from '../../../components/cardIndicadores/Indicadores&IoT/Umidade'
//import CardAmonia from '../../../components/cardIndicadores/Indicadores&IoT/Amonia'

import CardIndicadores from '../../../components/cardIndicadores/Indicadores&IoT/CardIndicadores'

//import { Callout } from 'react-native-maps'
//import * as shape from 'd3-shape'
//import { Circle, G, Line, Rect } from 'react-native-svg'

//import api from '../../../services/api'


function Indicadores() {

  

  return (
    <>

  <CardIndicadores /> 

    </>
  );
}

export default Indicadores;


{/*  {
    
    load ?

    <ActivityIndicator size={45} />

    :

    indicadores.reduce(t => (
    <CardIndicadores />  
    ))

    }

  */}
