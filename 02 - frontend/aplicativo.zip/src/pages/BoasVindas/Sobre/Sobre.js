import React from 'react';
import { View, StyleSheet, Text, Image, ScrollView } from 'react-native';
import Icon from '@expo/vector-icons/MaterialCommunityIcons'

//import Comunity from 'react-native-vector-icons/MaterialCommunityIcons'

//import { Ionicons, Octicons } from '@expo/vector-icons'


function Sobre() {

    return (
        <>

            <View style={styles.header}>
                <View style={styles.headerContent}>
                    <Text>        </Text>
                    <Image style={styles.avatar}
                        source={{ uri: 'https://avatars2.githubusercontent.com/u/43862551?s=460&v=4' }} />
                    <Text>                             </Text>
                    <Image style={styles.avatar}
                        source={{ uri: 'http://servicosweb.cnpq.br/wspessoa/servletrecuperafoto?tipo=1&id=K4731454Z2' }} />
                </View>

                <Text style={styles.name}>Msc. Lucas José de Souza     Dr. Egon Walter Wildauer</Text>
                <Text style={styles.userMail}>   souza.lucasj@gmail.com                    egon@ufpr.br</Text>
                <Text style={styles.userInfo}>UFPR - PPGGI                               UFPR - DECIGI</Text>

            </View>

            <View style={styles.body}>
                <ScrollView>
                    <Text style={styles.textInfo}>
                        Desenvolvido por: </Text>
                    <Text style={styles.autorInfo}>Lucas José de Souza</Text>
                    <Text style={styles.textInfo}>Sob a orientação de </Text><Text style={styles.autorInfo}>Dr. Egon Walter Wildauer</Text>
                    
                    <Text style={styles.textInfo}>e coorientação de:</Text>
                    <Text style={styles.autorInfo}>Dr. Andre Bellin Mariano</Text>
                    <Text style={styles.textInfo}>Projeto vinculado ao grupo de pesquisa:</Text>
                    <Text style={styles.autorInfo}>"Internet das Coisas aplicada na Cadeia Produtiva do Agronegócio - Agricultura 4.0"</Text>
                    <Text style={styles.textInfo}>Indicadores Nacionais:</Text>
                    <Text style={styles.autorInfo}>MACIEL, J. I. L. Indicadores para o agronegócio utilizando ferramenta web de visualização da informação. 2019. Dissertação (mestrado) - Universidade Federal do Paraná, Programa de Pós-Graduação em Ciência, Gestão e Tecnologia da Informação.</Text>
                    <Text style={styles.textInfo}>Agradecimento</Text>
                    <Text style={styles.autorInfo}>Ao Jhonny Ivair de Lima Maciel por autorizar o uso dos Indicadores Nacionais do Agronegócio <Icon name="language-r" size={20} color="blue"></Icon></Text>
                </ScrollView>

            </View>

            <View style={{ backgroundColor: '#ebeff2' }}><Text style={{ fontSize: 12, textAlign: 'center' }}>Versão beta 0.1</Text></View>
            <View>
                <Text style={styles.techs}>
                    <Icon name="raspberry-pi" size={45} color="#fff"> </Icon>
                    <Icon name="react" size={45} color="#fff"> </Icon>
                    <Icon name="android" size={45} color="#fff"> </Icon>
                    <Icon name="apple" size={45} color="white"> </Icon>
                    <Icon name="database" size={45} color="#fff"> </Icon>
                    <Icon name="visual-studio-code" size={45} color="white"> </Icon>
                </Text>
            </View>

        </>
    )
}

// <Comunity name="barley" size={45} color="#708090"> </Comunity>


const styles = StyleSheet.create({

    header: {
        backgroundColor: "#ebeff2",
        flex: 0.41,
        paddingTop: 5,
        paddingBottom: 20
    },

    headerContent: {
        alignItems: "center",
        borderColor: '#FFF',
        flexDirection: "row",
    },

    userInfo: {
        fontSize: 14,
        color: "#000",
        fontWeight: '600',
        textAlign: "center",

    },
    avatar: {
        width: 100,
        height: 100,
        borderRadius: 50,
        borderColor: "white",
        marginBottom: 5,
    },

    name: {
        fontSize: 14,
        color: "#000",
        fontWeight: '600',
        textAlign: "center",

    },

    textInfo: {
        fontSize: 16,
        marginTop: 2,
        color: "#000",
        textAlign: "justify",
        fontWeight: "bold",
        marginStart: 5


    },
    autorInfo: {
        fontSize: 16,
        color: "#000",
        textAlign: "justify",
        marginEnd: 10,
        marginStart: 5


    },

    userMail: {
        color: "#000",
        textAlign: "justify",
        fontWeight: '400'
    },

    body: {
        backgroundColor: "#ebeff2",
        height: 250,
        flex: 1
    },

    techs: {
        textAlign: 'center',
        backgroundColor: '#4169E1'
    }

});

export default Sobre;