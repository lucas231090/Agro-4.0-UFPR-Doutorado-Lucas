import React from "react";
import { StyleSheet, Text, View } from 'react-native'


const InfoCard = (props) => {

    // text princial darkTheme ? '#e0e0e0'  : 'white',

    // text secundario color: darkTheme ?'#adadad' : '#E4E4E4', 

    return(
        <View style={styles.card}>
            <Text style={styles.text}>{props.title}</Text>
            <Text style={[styles.text, {color: '#d3d3d3'}]}>{props.variable}</Text>
        </View>
    )
}
const styles = StyleSheet.create({   
    card:{
        alignItems: 'center'
      },
    text:{
        color: '#FFF',
        marginEnd: 15,
        fontSize: 12,
        alignSelf:"center",
        fontWeight:'bold'

      },
  });

export default InfoCard;